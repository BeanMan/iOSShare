//
//  AppDelegate.h
//  social
//
//  Created by bean on 16/5/7.
//  Copyright © 2016年 com.xile. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

